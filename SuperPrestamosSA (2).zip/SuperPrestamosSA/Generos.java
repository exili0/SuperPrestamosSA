package SuperPrestamosSA;

public enum Generos {
	MASCULINO,FEMENINO,NEUTRO;
}

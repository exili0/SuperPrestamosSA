package SuperPrestamosSA;

public enum Paises {

	EEUU,RUSIA,CHINA,JAPON;
}

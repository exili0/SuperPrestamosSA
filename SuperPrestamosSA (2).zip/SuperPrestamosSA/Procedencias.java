package SuperPrestamosSA;

public enum Procedencias {
	DC,MARVEL;
}

package SuperPrestamosSA;

import java.util.ArrayList;

public class Registro {
	
	protected String nickname,contrasenya;
		
	protected ArrayList<Administrador> listaAdmins = new ArrayList <>(5);
	protected ArrayList<SuperEmpresa> listaSuperEmpresas = new ArrayList <>(5);
	

}

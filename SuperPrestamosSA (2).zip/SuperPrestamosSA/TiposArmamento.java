package SuperPrestamosSA;

public enum TiposArmamento {
	HUMANO,ALIENIGENA,TECNOLOGICO;
}
